package com.example.sampleapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import androidx.leanback.widget.HorizontalGridView;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.FocusFinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;

import static com.example.sampleapp.R.*;

public class MainActivity extends FragmentActivity {
    GridView gridView;
int previousSelectedPosition=-1;
    List list;
    int size;

    Button play;

    GridView gridView1;

    String[] myTitles;
    String[] myDescriptions;
    int Images[]={R.drawable.movie, R.drawable.movie, R.drawable.movie, R.drawable.movie, R.drawable.movie, R.drawable.movie, drawable.movie, drawable.movie, drawable.movie};
    String[] myHeaders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

        Resources resources=getResources();
        myTitles=resources.getStringArray(array.titles);
        myDescriptions=resources.getStringArray(array.descriptions);
        myHeaders=resources.getStringArray(array.myheaders);

        gridView=findViewById(R.id.grid_view1);
        TextView headernum1 = gridView.findViewById(R.id.textView23);

       /* ArrayAdapter adapter=new ArrayAdapter(this, layout.simplehead, myHeaders);
        gridView.setAdapter(adapter);*/

        Headers adapter2=new Headers(this);
        gridView.setAdapter(adapter2);

       /*    gridView.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    TextView selectedItem = (TextView) gridView.getChildAt(i);
                    if (hasFocus) {
                        selectedItem.setTextColor(Color.RED);
                        selectedItem.getNextFocusForwardId();
                    } else {
                        selectedItem.setTextColor(Color.GRAY);

                    }
                }
            });*/


   gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            // Get the selected item text
            String selectedItem = parent.getItemAtPosition(position).toString();
            Toast.makeText(getApplicationContext(), selectedItem+"is the item selected", Toast.LENGTH_LONG).show();
                TextView tv = (TextView) view;

                tv.setBackgroundColor(Color.parseColor("#00000000"));
                tv.setTextColor(Color.RED);
                tv.setShadowLayer(5, 2, 2, Color.RED);

                // Get the last selected View from GridView
                TextView previousSelectedView = (TextView) gridView.getChildAt(previousSelectedPosition);
                if (previousSelectedPosition != -1) {
                    previousSelectedView.setSelected(false);
                    previousSelectedView.setBackgroundColor(Color.parseColor("#00000000"));
                    previousSelectedView.setTextColor(Color.GRAY);
                    previousSelectedView.setShadowLayer(0, 0, 0, Color.BLACK);
                }

                // Set the current selected view position as previousSelectedPosition
                previousSelectedPosition = position;
            }
    });

    play=findViewById(id.button2);
        Log.w("object", "Button adapter done");
        play.requestFocus();
        play.setFocusable(true);

//First Tray
        gridView1=findViewById(id.second_grid);
        size=Images.length;
        gridView1.setNumColumns(size);

        VivzAdapter adapter1=new VivzAdapter(this, myTitles, Images, myDescriptions);
        gridView1.setAdapter(adapter1);


//Second Tray
        gridView1=findViewById(id.second_grid_view);
        size=Images.length;
        gridView1.setNumColumns(size);

        VivzAdapter adapter3=new VivzAdapter(this, myTitles, Images, myDescriptions);
        gridView1.setAdapter(adapter3);


//Third Tray
        gridView1=findViewById(id.second_grid_view_1);
        size=Images.length;
        gridView1.setNumColumns(size);

        VivzAdapter adapter4=new VivzAdapter(this, myTitles, Images, myDescriptions);
        gridView1.setAdapter(adapter4);

    }

    public void sendMessage(View view)
    {
        Toast.makeText(this, "Play Button was clicked", Toast.LENGTH_SHORT).show();
    }
}


class VivzAdapter extends ArrayAdapter<String> {

    Context c;
    int[] images;
    String[] titleArray;
    String[] descriptionArray;

    public VivzAdapter(Context context, String[] titles, int[] imgs, String[] decps) {
        super(context, layout.single_row, id.textView2, titles);
        this.c = context;
        this.images = imgs;
        this.titleArray = titles;
        this.descriptionArray = decps;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(layout.single_row, parent, false);
        ImageView myImage = view.findViewById(id.imageView);
        TextView titles = view.findViewById(id.textView2);
        TextView descriptions = view.findViewById(id.textView3);
        myImage.setImageResource(images[position]);
        titles.setText(titleArray[position]);
        descriptions.setText(descriptionArray[position]);
        return view;
    }
}

