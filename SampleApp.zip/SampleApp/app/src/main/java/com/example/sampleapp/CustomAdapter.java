package com.example.sampleapp;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

class Headers extends BaseAdapter {
    Context context;
    String[] header;
    public Headers(Context c)
    {
        this.context=c;
        Resources res=c.getResources();
        header=res.getStringArray(R.array.myheaders);
    }

    @Override
    public int getCount() {
        return header.length;
    }

    @Override
    public Object getItem(int position) {
        return header[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view1 = inflater.inflate(R.layout.simplehead, parent, false);
        TextView headernum = view1.findViewById(R.id.textView23);
        headernum.setText(header[position]);
        return view1;
    }
}
